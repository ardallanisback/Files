This dataset includes ancient genotype data as described in Pilli et al. (2024) in PACKEDANCESTRYMAP format.

You may convert the data to other formats using the "convertf" utility of EIGENSOFT (https://data.broadinstitute.org/alkesgroup/EIGENSOFT/).

A number of different analyses can be performed using the appliations in ADMIXTOOLS (https://github.com/DReichLab/AdmixTools).

The dataset includes three files: *.geno (genotype data), *.ind (individual data), and *.snp (SNP data). Together they contain genotype information for 5 ancient individuals from Pompeii, Italy. 

BAM files:
You may find sequence read data for the individuals reported here in the European Nucleotide Archive (https://www.ebi.ac.uk/ena/) under accession number PRJEB74999.

Paper reference:
Elena Pilli, Stefania Vai, et al. "Ancient DNA challenges prevailing interpretations of the Pompeii plaster casts." Current Biology (2024).
Refer to Table 1 and DataS1 B for a tabular overview of the samples containing information on context and bioinformatic processing.
